# ============================================================
# CELL 4 — FEATURE EXTRACTION  (paste over original Cell 4)
# Key changes:
#   - Training generates 30s mashup → splits into 5s chunks → saves each chunk
#   - Val generates 30s mashup → splits into 5s chunks → saves all
#   - This makes val distribution much closer to test (30s mashups)
# ============================================================
import os, random, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import librosa
import soundfile as sf
from pathlib import Path
from tqdm import tqdm

random.seed(SEED)
np.random.seed(SEED)


def load_audio(path, sr=SAMPLE_RATE, duration=None):
    try:
        y, _ = librosa.load(path, sr=sr, duration=duration, mono=True)
    except Exception as e:
        print(f"load failed [{path}]: {e}")
        n = int((duration or 30) * sr)
        return np.zeros(n, dtype=np.float32)
    return y.astype(np.float32)


def pad_or_trim(y, length):
    if len(y) < length:
        y = np.pad(y, (0, length - len(y)))
    return y[:length].astype(np.float32)


def audio_to_melspec(y, sr=SAMPLE_RATE):
    """Convert a 5-second chunk to normalized mel-spectrogram."""
    y = pad_or_trim(y, CHUNK_SAMPLES)
    mel    = librosa.feature.melspectrogram(y=y, sr=sr, n_mels=N_MELS,
                                             n_fft=N_FFT, hop_length=HOP_LENGTH)
    mel_db = librosa.power_to_db(mel, ref=np.max)
    # Pad/trim time axis to FIXED_FRAMES
    if mel_db.shape[1] < FIXED_FRAMES:
        mel_db = np.pad(mel_db, ((0,0),(0, FIXED_FRAMES-mel_db.shape[1])),
                        constant_values=mel_db.min())
    else:
        mel_db = mel_db[:, :FIXED_FRAMES]
    lo, hi = mel_db.min(), mel_db.max()
    return ((mel_db - lo) / (hi - lo + 1e-8)).astype(np.float32)


def add_noise(y, noise_pool, sr=SAMPLE_RATE):
    if not noise_pool or random.random() > NOISE_ADD_PROB:
        return y
    noise = load_audio(random.choice(noise_pool), sr=sr, duration=len(y)/sr)
    noise = pad_or_trim(noise, len(y))
    sig_pwr    = np.mean(y**2) + 1e-9
    nse_pwr    = np.mean(noise**2) + 1e-9
    target_pwr = sig_pwr / (10 ** (random.uniform(NOISE_SNR_MIN, NOISE_SNR_MAX) / 10))
    scale      = np.sqrt(target_pwr / nse_pwr)
    return (y + scale * noise).astype(np.float32)


def normalize_audio(y, peak=0.8):
    mx = np.abs(y).max()
    return (y / mx * peak).astype(np.float32) if mx > 0 else y


def augment_waveform(y, sr=SAMPLE_RATE):
    aug = random.choice(["none", "pitch", "stretch", "both"])
    if aug in ("pitch", "both"):
        y = librosa.effects.pitch_shift(y, sr=sr, n_steps=random.uniform(-2, 2))
    if aug in ("stretch", "both"):
        y = librosa.effects.time_stretch(y, rate=random.uniform(0.85, 1.15))
    return y


def discover_songs(stems_dir):
    print("Scanning genres_stems/ ...")
    songs = {}
    for genre in GENRES:
        genre_dir = os.path.join(stems_dir, genre)
        if not os.path.exists(genre_dir):
            songs[genre] = []; continue
        song_list = []
        for folder in sorted(os.listdir(genre_dir)):
            fpath = os.path.join(genre_dir, folder)
            if not os.path.isdir(fpath): continue
            stem_paths = {s: os.path.join(fpath, f"{s}.wav") for s in STEMS}
            if all(os.path.exists(p) for p in stem_paths.values()):
                song_list.append(stem_paths)
        songs[genre] = song_list
        print(f"  {genre:<12}: {len(song_list)} songs")
    return songs


def discover_noise(esc50_dir):
    if not os.path.exists(esc50_dir): return []
    files = [os.path.join(esc50_dir, f)
             for f in os.listdir(esc50_dir) if f.lower().endswith(".wav")]
    print(f"Found {len(files)} ESC-50 noise files")
    return files


# KEY FIX: make_mashup creates a full 30s mix, then we slice into 5s chunks
# This matches test distribution: 30s mashup → chunk → classify
def make_full_mashup(songs, genre, noise_pool, full_dur=DURATION):
    """
    Create a 30s mashup by:
    1. Picking 4 different songs (one per stem, from same genre)
    2. Mixing them (simulating tempo-sync assumption)
    3. Adding ESC-50 noise at aggressive SNR
    Returns: (30*sr,) float32 array
    """
    pool   = songs[genre]
    n      = len(pool)
    target = int(full_dur * SAMPLE_RATE)
    mixed  = np.zeros(target, dtype=np.float32)

    for stem in STEMS:
        # Pick a DIFFERENT random song for each stem → true cross-song mashup
        idx   = random.randint(0, n - 1)
        audio = load_audio(pool[idx][stem], sr=SAMPLE_RATE, duration=full_dur)
        audio = pad_or_trim(audio, target)
        # Augment ~40% of stems
        if random.random() < 0.4:
            audio = augment_waveform(audio)
            audio = pad_or_trim(audio, target)
        mixed += random.uniform(0.4, 1.3) * audio

    mixed = normalize_audio(mixed)
    # Add ESC-50 noise to the full 30s mix
    if noise_pool and random.random() < NOISE_ADD_PROB:
        noise = load_audio(random.choice(noise_pool), sr=SAMPLE_RATE, duration=full_dur)
        noise = pad_or_trim(noise, target)
        # Optionally paste noise at random position (simulate test construction)
        if random.random() < 0.5:
            start = random.randint(0, max(0, target - len(noise)))
            noise_placed = np.zeros(target, dtype=np.float32)
            end = min(start + len(noise), target)
            noise_placed[start:end] = noise[:end-start]
            noise = noise_placed
        sig_pwr    = np.mean(mixed**2) + 1e-9
        nse_pwr    = np.mean(noise**2) + 1e-9
        target_pwr = sig_pwr / (10 ** (random.uniform(NOISE_SNR_MIN, NOISE_SNR_MAX)/10))
        scale      = np.sqrt(target_pwr / nse_pwr)
        mixed      = (mixed + scale * noise).astype(np.float32)
        mixed      = normalize_audio(mixed)
    return mixed


def mashup_to_chunks(mixed, chunk_dur=CHUNK_DURATION):
    """Split 30s array into 5s chunks → list of mel-spectrograms."""
    cs  = int(chunk_dur * SAMPLE_RATE)
    total = len(mixed)
    mels  = []
    for start in range(0, total, cs):
        chunk = mixed[start:start+cs]
        mels.append(audio_to_melspec(chunk))
    return mels   # 6 chunks for 30s audio


def extract_mel_features(songs, noise_pool):
    train_manifest, val_manifest = [], []

    for genre in GENRES:
        song_list = songs.get(genre, [])
        if not song_list: print(f"Skipping {genre}: no songs"); continue

        n_val   = max(1, int(len(song_list) * VAL_SPLIT))
        n_train = len(song_list) - n_val
        n_aug   = n_train * N_AUG_PER_SONG

        print(f"\n  {genre}: {n_train} train → {n_aug} mashups × 6 chunks = {n_aug*6} mel-specs")

        # TRAIN: generate augmented 30s mashups → split into 5s chunks
        for i in tqdm(range(n_aug), desc=f"    {genre} train", leave=False):
            mixed = make_full_mashup(songs, genre, noise_pool, full_dur=DURATION)
            chunks = mashup_to_chunks(mixed)
            for j, mel in enumerate(chunks):
                fpath = os.path.join(TRAIN_FEAT_DIR, f"{genre}_{i:05d}_c{j}.npy")
                np.save(fpath, mel)
                train_manifest.append([fpath, genre])

        # VAL: use last n_val songs but still create a mashup-style mix
        print(f"  {genre}: {n_val} val songs")
        val_songs = song_list[n_train:]
        for j in tqdm(range(20), desc=f"    {genre} val", leave=False):
            # Val: also full 30s mashup, less augmentation
            target = int(DURATION * SAMPLE_RATE)
            mixed  = np.zeros(target, dtype=np.float32)
            for stem in STEMS:
                idx   = random.randint(0, len(val_songs)-1)
                audio = load_audio(val_songs[idx][stem], sr=SAMPLE_RATE, duration=DURATION)
                audio = pad_or_trim(audio, target)
                mixed += random.uniform(0.6, 1.2) * audio
            mixed = normalize_audio(mixed)
            mixed = add_noise(mixed, noise_pool)
            chunks = mashup_to_chunks(mixed)
            for k, mel in enumerate(chunks):
                fpath = os.path.join(VAL_FEAT_DIR, f"{genre}_val_{j:05d}_c{k}.npy")
                np.save(fpath, mel)
                # Store song-level id too for grouped scoring
                val_manifest.append([fpath, genre, f"{genre}_val_{j:05d}"])

    return train_manifest, val_manifest


# ── Run ──────────────────────────────────────────────────────────────────────
print("=" * 60)
print("FEATURE EXTRACTION (improved)")
print("=" * 60)

print("\n[1] Discovering songs...")
songs = discover_songs(STEMS_DIR)
total = sum(len(v) for v in songs.values())
print(f"Total: {total}")
if total == 0:
    raise RuntimeError("No songs found.")

print("\n[2] Discovering noise...")
noise_pool = discover_noise(ESC50_AUDIO_DIR)

print("\n[3] Mel-spectrogram features (30s mashup → 5s chunks)...")
train_manifest, val_manifest = extract_mel_features(songs, noise_pool)

train_df = pd.DataFrame(train_manifest, columns=["path","genre"])
val_df   = pd.DataFrame(val_manifest,   columns=["path","genre","song_id"])
train_df.to_csv(os.path.join(FEATURES_DIR,"train_manifest.csv"), index=False)
val_df.to_csv(  os.path.join(FEATURES_DIR,"val_manifest.csv"),   index=False)

npy_files = list(Path(FEATURES_DIR).rglob("*.npy"))
print(f"\nTotal .npy files : {len(npy_files)}")
print(f"Train samples    : {len(train_df)}")
print(f"Val samples      : {len(val_df)}")
print(f"Disk usage       : {sum(f.stat().st_size for f in npy_files)/1e9:.2f} GB")
print("\nFeature extraction complete!")
