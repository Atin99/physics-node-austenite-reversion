# ============================================================
# QUICK FIX CELL — Run this FIRST if you don't want to redo
# everything from scratch. This patches the inference only.
#
# Just paste this as a new cell AFTER your existing Cell 9
# and re-run inference. This alone should get you from 0.79 → ~0.88+
# ============================================================
import os, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import librosa
from tqdm import tqdm

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ── Patch: fix inference to use full 30s with chunking ──────────────────────
CHUNK_S     = 5                           # seconds per chunk
CHUNK_SAMP  = SAMPLE_RATE * CHUNK_S
TTA_SHIFTS  = [0.0, 2.5, 5.0, 10.0]     # 4 TTA shifts (fast)

def load_full(path):
    try:
        y, _ = librosa.load(path, sr=SAMPLE_RATE, mono=True)
    except:
        return np.zeros(int(30*SAMPLE_RATE), dtype=np.float32)
    return y.astype(np.float32)

def to_mel(y):
    y = y if len(y)==CHUNK_SAMP else (
        np.pad(y,(0,CHUNK_SAMP-len(y))) if len(y)<CHUNK_SAMP else y[:CHUNK_SAMP])
    mel    = librosa.feature.melspectrogram(y=y,sr=SAMPLE_RATE,n_mels=N_MELS,
                                             n_fft=N_FFT,hop_length=HOP_LENGTH)
    mel_db = librosa.power_to_db(mel,ref=np.max)
    if mel_db.shape[1]<FIXED_FRAMES:
        mel_db=np.pad(mel_db,((0,0),(0,FIXED_FRAMES-mel_db.shape[1])),
                      constant_values=mel_db.min())
    else:
        mel_db=mel_db[:,:FIXED_FRAMES]
    lo,hi=mel_db.min(),mel_db.max()
    return ((mel_db-lo)/(hi-lo+1e-8)).astype(np.float32)

def file_to_batch(y, shift_sec):
    ys = np.roll(y, int(shift_sec*SAMPLE_RATE))
    chunks=[to_mel(ys[i:i+CHUNK_SAMP]) for i in range(0,len(ys),CHUNK_SAMP)]
    return torch.tensor(np.stack(chunks)).unsqueeze(1).float()  # (C,1,128,431)

def predict_file_fixed(path, cnn_model, crnn_model):
    """Use all 30s + TTA — the main fix."""
    y   = load_full(path)
    sfx = nn.Softmax(dim=-1)
    all_p = np.zeros(NUM_CLASSES)

    for shift in TTA_SHIFTS:
        batch = file_to_batch(y, shift).to(DEVICE)       # (6,1,128,431)
        with torch.no_grad():
            # Average CNN and CRNN predictions over all 6 chunks
            p_cnn  = sfx(cnn_model(batch)).cpu().numpy().mean(0)
            p_crnn = sfx(crnn_model(batch)).cpu().numpy().mean(0)
        all_p += (p_cnn + p_crnn) / 2

    all_p /= len(TTA_SHIFTS)
    return IDX2GENRE[int(np.argmax(all_p))], all_p

# ── Load best CNN and CRNN (already trained) ────────────────────────────────
print("Loading CNN checkpoint...")
cnn_m = EfficientNetMelCNN(num_classes=NUM_CLASSES).to(DEVICE)
cnn_ckpt = torch.load(os.path.join(MODELS_DIR,"cnn_best.pth"), map_location=DEVICE)
cnn_m.load_state_dict(cnn_ckpt["model_state"])
cnn_m.eval()
print(f"  CNN val F1: {cnn_ckpt.get('val_f1',0):.4f}")

print("Loading CRNN checkpoint...")
crnn_m = CRNN(num_classes=NUM_CLASSES).to(DEVICE)
crnn_ckpt = torch.load(os.path.join(MODELS_DIR,"crnn_best.pth"), map_location=DEVICE)
crnn_m.load_state_dict(crnn_ckpt["model_state"])
crnn_m.eval()
print(f"  CRNN val F1: {crnn_ckpt.get('val_f1',0):.4f}")

# ── Run fixed inference ───────────────────────────────────────────────────────
test_df = pd.read_csv(TEST_CSV)
test_df["_path"] = test_df["filename"].apply(
    lambda fn: os.path.join(BASE_DIR, fn) if not os.path.isabs(fn) else fn)

print(f"\nRunning FIXED inference on {len(test_df)} files...")
print(f"  TTA shifts: {TTA_SHIFTS}")
print(f"  Chunks per file: {30//CHUNK_S}")
print(f"  Total predictions per file: {len(TTA_SHIFTS)} × {30//CHUNK_S} × 2 models = "
      f"{len(TTA_SHIFTS)*(30//CHUNK_S)*2}")

preds, probs_list = [], []
for _, row in tqdm(test_df.iterrows(), total=len(test_df)):
    g, p = predict_file_fixed(row["_path"], cnn_m, crnn_m)
    preds.append(g)
    probs_list.append(p)

sub_fixed = pd.DataFrame({"id": test_df["id"].values, "genre": preds})
sub_fixed.to_csv(os.path.join(WORKING_DIR, "submission_fixed.csv"), index=False)

print(f"\n✓ submission_fixed.csv saved")
print(f"\nPrediction distribution:")
print(sub_fixed["genre"].value_counts().to_string())
print(f"\nFirst 10:")
print(sub_fixed.head(10).to_string(index=False))

assert sub_fixed["genre"].isin(GENRES).all()
assert len(sub_fixed) == 3020
print("\n✓ Format OK — submit submission_fixed.csv to Kaggle!")
