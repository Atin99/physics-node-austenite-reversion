# ============================================================
# CELL 7 — Train CRNN  (paste over original Cell 7)
# ============================================================
# (All helper functions are already in memory from Cell 6)

import wandb
wandb.login(key=WANDB_API_KEY)

model_crnn = CRNN(num_classes=NUM_CLASSES, gru_hidden=512, gru_layers=2, dropout=0.3).to(DEVICE)
run_training(model_crnn, train_df, val_df,
             run_name="crnn_v2",
             model_fname="crnn_best.pth",
             lr=LR)

# ============================================================
# CELL 8 — Train ResNet50  (replaces original wav2vec2 cell)
# Why ResNet50 instead of wav2vec2?
#   - wav2vec2 val F1 was 0.80 (dragging ensemble down)
#   - wav2vec2 inference was 3× slower (7 min alone)
#   - ResNet50 on mel specs: deeper features, similar speed to EfficientNet
#   - 3 mel-based models can be ensembled consistently
# ============================================================
import wandb
wandb.login(key=WANDB_API_KEY)

model_resnet = ResNet50MelCNN(num_classes=NUM_CLASSES).to(DEVICE)
backbone_p2 = [p for n,p in model_resnet.named_parameters() if "fc" not in n]
head_p2     = [p for n,p in model_resnet.named_parameters() if "fc" in n]
run_training(model_resnet, train_df, val_df,
             run_name="resnet50_v1",
             model_fname="resnet_best.pth",
             backbone_params=backbone_p2,
             head_params=head_p2)
