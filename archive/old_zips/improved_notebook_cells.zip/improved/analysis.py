"""
ROOT CAUSE ANALYSIS — Why val F1 = 0.99 but Kaggle LB = 0.79
=============================================================

BUG 1 (CRITICAL): Inference only reads first 10s of 30s test files
  - load_audio(..., duration=DURATION)  where DURATION=10
  - Test files are exactly 30s → 66% of the audio is IGNORED
  - Fix: chunk each 30s file into 6×5s or 3×10s segments, predict all, average

BUG 2 (CRITICAL): Ensemble weights are backwards
  - wav2vec2 val F1 = 0.803  → gets weight 2.0  (HURTS)
  - CNN val F1     = 0.985  → gets weight 1.0
  - CRNN val F1    = 0.990  → gets weight 1.0
  - Fix: weight by val F1, or remove wav2vec2 from ensemble

BUG 3 (MAJOR): Val set is too easy / not representative
  - Val uses make_clean_melspec(val_songs, noise_pool) — single song, mild noise
  - Test is true cross-song mashup with heavy tempo sync + ESC-50
  - Val F1=0.99 is overoptimistic; test distribution is harder

BUG 4 (MINOR): Wav2Vec2 overfits to raw audio mix (train F1=0.999, val=0.80)
  - The 5s raw clips don't capture enough temporal context for genre
  - Better: use AST (Audio Spectrogram Transformer) fine-tuned on AudioSet

SPEED: Inference took 24 min because of 10 TTA × 5 TTA for each of 3020 files
  - wav2vec2 inference is ~3× slower than mel models
  - Fix: use only CNN+CRNN ensemble (0.987 combined val F1) + 6-chunk inference
"""
