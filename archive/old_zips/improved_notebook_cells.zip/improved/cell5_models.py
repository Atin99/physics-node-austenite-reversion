# ============================================================
# CELL 5 — MODEL ARCHITECTURES  (paste over original Cell 5)
# Changes:
#   - EfficientNetMelCNN: unchanged (was working well)
#   - CRNN: add depth (5 blocks), increase GRU hidden to 512
#   - NEW: ResNet50MelCNN — stronger backbone for better features
# ============================================================
import torch
import torch.nn as nn
import torchvision.models as tv_models


# ── Model 1: EfficientNet-B0 (unchanged — was 0.985 val F1) ─────────────────
class EfficientNetMelCNN(nn.Module):
    def __init__(self, num_classes=10):
        super().__init__()
        base = tv_models.efficientnet_b0(weights=tv_models.EfficientNet_B0_Weights.DEFAULT)
        in_features = base.classifier[1].in_features
        base.classifier = nn.Sequential(
            nn.Dropout(0.4),
            nn.Linear(in_features, 256),
            nn.SiLU(),
            nn.Dropout(0.3),
            nn.Linear(256, num_classes),
        )
        self.model = base

    def forward(self, x):
        x = x.repeat(1, 3, 1, 1)
        return self.model(x)


# ── Model 2: CRNN with deeper CNN and larger GRU ─────────────────────────────
class CRNN(nn.Module):
    def __init__(self, num_classes=10, gru_hidden=512, gru_layers=2, dropout=0.3):
        super().__init__()

        def cnn_block(in_ch, out_ch, pool=(2,2)):
            return nn.Sequential(
                nn.Conv2d(in_ch, out_ch, 3, padding=1, bias=False),
                nn.BatchNorm2d(out_ch),
                nn.GELU(),
                nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
                nn.BatchNorm2d(out_ch),
                nn.GELU(),
                nn.MaxPool2d(pool),
                nn.Dropout2d(0.1),
            )

        # 5 blocks: freq axis 128→64→32→16→8→4; time axis 431→215→107→53→26→13
        self.cnn = nn.Sequential(
            cnn_block(1,   64,  (2,2)),
            cnn_block(64,  128, (2,2)),
            cnn_block(128, 256, (2,2)),
            cnn_block(256, 512, (2,2)),
            cnn_block(512, 512, (2,1)),  # collapse freq only
        )

        self.freq_pool = nn.AdaptiveAvgPool2d((1, None))  # → (B, 512, 1, T')

        self.gru = nn.GRU(
            input_size=512,
            hidden_size=gru_hidden,
            num_layers=gru_layers,
            batch_first=True,
            dropout=dropout if gru_layers > 1 else 0.0,
            bidirectional=True,
        )
        gru_out = gru_hidden * 2
        self.attn = nn.Linear(gru_out, 1)
        self.classifier = nn.Sequential(
            nn.LayerNorm(gru_out),
            nn.Linear(gru_out, 512),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(512, num_classes),
        )
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None: nn.init.zeros_(m.bias)

    def forward(self, x):
        x      = self.cnn(x)
        x      = self.freq_pool(x).squeeze(2)   # (B, 512, T')
        x      = x.permute(0, 2, 1)             # (B, T', 512)
        out, _ = self.gru(x)                     # (B, T', gru_out)
        weights = torch.softmax(self.attn(out), dim=1)
        pooled  = (out * weights).sum(dim=1)
        return self.classifier(pooled)


# ── Model 3: ResNet50 — stronger backbone ────────────────────────────────────
# ResNet50 has a much deeper representation capacity than EfficientNet-B0.
# For mel-spectrograms where fine-grained frequency patterns matter,
# the deeper feature hierarchy helps separate similar-sounding genres.
class ResNet50MelCNN(nn.Module):
    def __init__(self, num_classes=10):
        super().__init__()
        base = tv_models.resnet50(weights=tv_models.ResNet50_Weights.DEFAULT)
        in_features = base.fc.in_features
        base.fc = nn.Sequential(
            nn.Dropout(0.4),
            nn.Linear(in_features, 512),
            nn.GELU(),
            nn.Dropout(0.3),
            nn.Linear(512, num_classes),
        )
        self.model = base

    def forward(self, x):
        x = x.repeat(1, 3, 1, 1)   # (B,1,128,431) → (B,3,128,431)
        return self.model(x)


def count_params(model):
    total     = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return total, trainable


# Quick sanity check
_x = torch.randn(2, 1, 128, 431)
for name, cls in [("EfficientNetMelCNN", EfficientNetMelCNN),
                  ("CRNN",               CRNN),
                  ("ResNet50MelCNN",     ResNet50MelCNN)]:
    m = cls(10)
    out = m(_x)
    t, tr = count_params(m)
    assert out.shape == (2, 10), f"{name} shape mismatch"
    print(f"{name:<22}: {t:>12,} total / {tr:>12,} trainable  output={out.shape}")

print("All models OK.")
