# ============================================================
# CELL 1 — CONFIG  (paste over original Cell 1)
# Key changes: DURATION=30, CHUNK_DURATION=5, more augmentation
# ============================================================
import os

try:
    from kaggle_secrets import UserSecretsClient
    WANDB_API_KEY = UserSecretsClient().get_secret("WANDB_API_KEY")
except Exception:
    WANDB_API_KEY = os.environ.get("WANDB_API_KEY", "")

WANDB_PROJECT = "23f3001973-t12026"
WANDB_ENTITY  = "23f3001973-iitm-india"

BASE_DIR         = "/kaggle/input/jan-2026-dl-gen-ai-project/messy_mashup"
STEMS_DIR        = os.path.join(BASE_DIR, "genres_stems")
ESC50_AUDIO_DIR  = os.path.join(BASE_DIR, "ESC-50-master", "audio")
MASHUPS_DIR      = os.path.join(BASE_DIR, "mashups")
TEST_CSV         = os.path.join(BASE_DIR, "test.csv")

WORKING_DIR    = "/kaggle/working"
FEATURES_DIR   = os.path.join(WORKING_DIR, "features")
TRAIN_FEAT_DIR = os.path.join(FEATURES_DIR, "train")
VAL_FEAT_DIR   = os.path.join(FEATURES_DIR, "val")
MODELS_DIR     = os.path.join(WORKING_DIR,  "models")
PLOTS_DIR      = os.path.join(WORKING_DIR,  "plots")

for _d in [FEATURES_DIR, TRAIN_FEAT_DIR, VAL_FEAT_DIR, MODELS_DIR, PLOTS_DIR]:
    os.makedirs(_d, exist_ok=True)

SAMPLE_RATE    = 22050
# FIX: test files are exactly 30s — train on 30s chunks too
DURATION       = 30                     # was 10 → CRITICAL FIX
CHUNK_DURATION = 5                      # split into 5s chunks for model input
CHUNK_SAMPLES  = SAMPLE_RATE * CHUNK_DURATION
N_MELS         = 128
N_FFT          = 2048
HOP_LENGTH     = 512
# frames for a 5s chunk at hop=512
FIXED_FRAMES   = (CHUNK_SAMPLES // HOP_LENGTH) + 1   # 431
STEMS          = ["drums", "vocals", "bass", "other"]

GENRES = ["blues","classical","country","disco","hiphop",
          "jazz","metal","pop","reggae","rock"]
NUM_CLASSES = len(GENRES)
GENRE2IDX   = {g: i for i, g in enumerate(GENRES)}
IDX2GENRE   = {i: g for i, g in enumerate(GENRES)}

# More augmentation samples to increase diversity
N_AUG_PER_SONG  = 30     # was 20 → more samples per genre
VAL_SPLIT       = 0.2
# FIX: aggressive noise to match test distribution (test has low SNR)
NOISE_SNR_MIN   = 2      # was 3 → lower = more noise = closer to test
NOISE_SNR_MAX   = 15     # was 20 → cap at 15
NOISE_ADD_PROB  = 0.95   # was 0.90

BATCH_SIZE    = 32
NUM_EPOCHS    = 80
LR            = 1e-3
WEIGHT_DECAY  = 1e-4
NUM_WORKERS   = 2
SEED          = 42
PATIENCE      = 15

print("Config loaded.")
print(f"  DURATION (training)   : {DURATION}s")
print(f"  CHUNK_DURATION        : {CHUNK_DURATION}s  ({FIXED_FRAMES} frames)")
print(f"  N_AUG_PER_SONG        : {N_AUG_PER_SONG}")
print(f"  NOISE_SNR range       : [{NOISE_SNR_MIN}, {NOISE_SNR_MAX}] dB")
