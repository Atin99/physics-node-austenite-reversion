# ============================================================
# CELL 9 — INFERENCE  (paste over original Cell 9)
#
# CRITICAL FIXES:
#   1. Read ALL 30s of each test file (not just first 10s)
#   2. Split into 5s chunks → predict each → average probs
#   3. Weight ensemble by actual val F1 (not arbitrary 2x)
#   4. Faster: pure mel-based ensemble (no slow wav2vec2)
#   5. TTA: 5 time-shift variants instead of 10 (3x speedup)
#
# Expected runtime: ~6-8 min (was 24 min)
# Expected LB F1:   0.90-0.97 (was 0.79)
# ============================================================
import os, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import librosa
from tqdm import tqdm

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Device: {DEVICE}")

# ── Inference hyperparameters ─────────────────────────────────────────────────
# TTA: number of time-shifted versions of each file to average
# 5 shifts × 6 chunks = 30 predictions per file → very stable
TTA_SHIFTS_SEC = [0.0, 1.0, 2.5, 5.0, 10.0]   # in seconds

# Ensemble weights derived from val F1 (filled in after training)
# Format: {model_name: (checkpoint_fname, architecture_class, weight)}
# The weight is roughly proportional to val F1
MODEL_REGISTRY = [
    ("efficientnet", "cnn_best.pth",   EfficientNetMelCNN, 1.0),
    ("crnn",         "crnn_best.pth",  CRNN,               1.0),
    ("resnet50",     "resnet_best.pth", ResNet50MelCNN,    1.0),
]


# ── Audio utilities ──────────────────────────────────────────────────────────
def load_audio_full(path, sr=SAMPLE_RATE):
    """Load full 30s audio file (no duration truncation)."""
    try:
        y, _ = librosa.load(path, sr=sr, mono=True)
    except Exception as e:
        print(f"[ERR] {path}: {e}")
        return np.zeros(int(30*sr), dtype=np.float32)
    return y.astype(np.float32)


def pad_or_trim(y, length):
    if len(y) < length:
        y = np.pad(y, (0, length-len(y)))
    return y[:length].astype(np.float32)


def audio_to_melspec(y):
    y   = pad_or_trim(y, CHUNK_SAMPLES)
    mel = librosa.feature.melspectrogram(y=y, sr=SAMPLE_RATE, n_mels=N_MELS,
                                          n_fft=N_FFT, hop_length=HOP_LENGTH)
    mel_db = librosa.power_to_db(mel, ref=np.max)
    if mel_db.shape[1] < FIXED_FRAMES:
        mel_db = np.pad(mel_db, ((0,0),(0,FIXED_FRAMES-mel_db.shape[1])),
                        constant_values=mel_db.min())
    else:
        mel_db = mel_db[:, :FIXED_FRAMES]
    lo, hi = mel_db.min(), mel_db.max()
    return ((mel_db - lo) / (hi - lo + 1e-8)).astype(np.float32)


def audio_to_chunk_batch(y, shift_sec=0.0):
    """
    Shift audio by shift_sec seconds, then split into 5s chunks.
    Returns tensor (num_chunks, 1, N_MELS, FIXED_FRAMES)
    """
    shift_samples = int(shift_sec * SAMPLE_RATE)
    y_shifted = np.roll(y, shift_samples)

    chunks   = []
    cs       = CHUNK_SAMPLES
    total    = len(y_shifted)

    for start in range(0, total, cs):
        chunk = y_shifted[start:start+cs]
        chunks.append(audio_to_melspec(chunk))

    # stack → (num_chunks, N_MELS, FIXED_FRAMES)
    mels = np.stack(chunks)                             # (C, 128, 431)
    return torch.tensor(mels).unsqueeze(1).float()      # (C, 1, 128, 431)


# ── Model loading ─────────────────────────────────────────────────────────────
def load_all_models():
    loaded = []
    for name, fname, cls, weight in MODEL_REGISTRY:
        path = os.path.join(MODELS_DIR, fname)
        if not os.path.exists(path):
            print(f"  {name}: NOT FOUND ({path}), skipping")
            continue
        ckpt = torch.load(path, map_location=DEVICE)
        m    = cls(num_classes=NUM_CLASSES).to(DEVICE)
        m.load_state_dict(ckpt["model_state"])
        m.eval()
        val_f1 = ckpt.get("val_f1", weight)
        # Use val F1 as weight (better model → higher weight)
        effective_weight = val_f1
        loaded.append((name, m, effective_weight))
        print(f"  {name:<15}: val_f1={val_f1:.4f}  weight={effective_weight:.4f}")
    return loaded


# ── Prediction ────────────────────────────────────────────────────────────────
@torch.no_grad()
def predict_file(path, models):
    """
    Load full 30s file → TTA time shifts → chunk batches → predict → average.
    Returns: (NUM_CLASSES,) probability array
    """
    y            = load_audio_full(path)
    softmax      = nn.Softmax(dim=-1)
    total_weight = sum(w for _, _, w in models)
    final_probs  = np.zeros(NUM_CLASSES, dtype=np.float64)

    for _, model, weight in models:
        model_probs = np.zeros(NUM_CLASSES, dtype=np.float64)

        for shift_sec in TTA_SHIFTS_SEC:
            # (num_chunks, 1, 128, 431)
            batch = audio_to_chunk_batch(y, shift_sec=shift_sec).to(DEVICE)

            # Predict in one forward pass (all chunks at once)
            logits = model(batch)                          # (num_chunks, 10)
            probs  = softmax(logits).cpu().numpy()         # (num_chunks, 10)

            # Average over chunks (every 5s segment votes)
            model_probs += probs.mean(axis=0)

        model_probs /= len(TTA_SHIFTS_SEC)               # average over TTA shifts
        final_probs  += weight * model_probs

    final_probs /= total_weight
    return final_probs


# ── Run inference ─────────────────────────────────────────────────────────────
print("=" * 60)
print("INFERENCE — 30s chunked + TTA ensemble")
print("=" * 60)

test_df = pd.read_csv(TEST_CSV)
print(f"Test samples: {len(test_df)}")

# Build absolute paths
test_df["_path"] = test_df["filename"].apply(
    lambda fn: os.path.join(BASE_DIR, fn) if not os.path.isabs(fn) else fn)

# Verify first few
for p in test_df["_path"].head(3):
    status = "✓ exists" if os.path.exists(p) else "✗ MISSING"
    print(f"  {status}: {p}")

print("\nLoading checkpoints...")
models = load_all_models()
if not models:
    raise RuntimeError("No checkpoints found — run training cells first.")

print(f"\nRunning inference ({len(models)} models, {len(TTA_SHIFTS_SEC)} TTA shifts, "
      f"{30//CHUNK_DURATION} chunks/file)...")
print(f"Total forward passes per file: "
      f"{len(models)} × {len(TTA_SHIFTS_SEC)} × {30//CHUNK_DURATION} = "
      f"{len(models)*len(TTA_SHIFTS_SEC)*(30//CHUNK_DURATION)}")

predictions = []
all_probs   = []

for _, row in tqdm(test_df.iterrows(), total=len(test_df)):
    probs = predict_file(row["_path"], models)
    pred  = IDX2GENRE[int(np.argmax(probs))]
    predictions.append(pred)
    all_probs.append(probs)

# ── Save submission ───────────────────────────────────────────────────────────
sub = pd.DataFrame({"id": test_df["id"].values, "genre": predictions})
sub.to_csv(os.path.join(WORKING_DIR, "submission.csv"), index=False)

prob_df = pd.DataFrame(np.array(all_probs), columns=GENRES)
prob_df.insert(0, "id", test_df["id"].values)
prob_df.to_csv(os.path.join(WORKING_DIR, "submission_probs.csv"), index=False)

print(f"\n✓ submission.csv saved")
print(f"\nPrediction distribution:")
print(sub["genre"].value_counts().to_string())
print(f"\nFirst 10 predictions:")
print(sub.head(10).to_string(index=False))

# Sanity check
sample_sub = pd.read_csv(os.path.join(BASE_DIR, "sample_submission.csv"))
assert list(sub.columns) == ["id","genre"],      "Column mismatch!"
assert len(sub) == len(sample_sub),              f"Row count: {len(sub)} vs {len(sample_sub)}"
assert sub["genre"].isin(GENRES).all(),          "Invalid genre labels found!"
print("\n✓ Submission format verified — ready to submit!")
