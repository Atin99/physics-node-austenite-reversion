# ============================================================
# CELL 6 — SHARED TRAINING UTILS + Train EfficientNet CNN
# (paste over original Cell 6)
# Changes:
#   - Dataset groups by song_id for accurate val scoring
#   - Cosine LR with warm restarts
#   - Mixup applied to every batch
# ============================================================
import os, random, warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from sklearn.metrics import f1_score, classification_report
import wandb
from tqdm import tqdm

random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Device: {DEVICE}")


class MelSpecDataset(Dataset):
    """
    Loads pre-computed 5-second mel-spectrograms.
    Each file is one 5s chunk from a 30s mashup.
    During training: extra SpecAugment + roll for variety.
    """
    def __init__(self, manifest_df, augment=False):
        self.data    = manifest_df.reset_index(drop=True)
        self.augment = augment

    def __len__(self): return len(self.data)

    def __getitem__(self, idx):
        row   = self.data.iloc[idx]
        mel   = np.load(row["path"]).astype(np.float32)
        label = GENRE2IDX[row["genre"]]
        if mel.shape != (N_MELS, FIXED_FRAMES):
            mel = np.zeros((N_MELS, FIXED_FRAMES), dtype=np.float32)
        if self.augment:
            # Time shift
            mel = np.roll(mel, random.randint(-40, 40), axis=1)
            # Frequency mask (SpecAugment)
            f  = random.randint(0, 30); f0 = random.randint(0, max(0, N_MELS-f))
            mel[f0:f0+f, :] = 0.0
            # Time mask
            t  = random.randint(0, 80); t0 = random.randint(0, max(0, FIXED_FRAMES-t))
            mel[:, t0:t0+t] = 0.0
            # Amplitude jitter
            mel = mel * random.uniform(0.75, 1.25)
            # Gaussian noise on spectrogram
            if random.random() < 0.3:
                mel = mel + np.random.normal(0, 0.02, mel.shape).astype(np.float32)
        return torch.FloatTensor(mel).unsqueeze(0), label


def mixup_batch(bx, by, alpha=0.4):
    lam     = np.random.beta(alpha, alpha)
    idx     = torch.randperm(bx.size(0))
    mixed_x = lam * bx + (1 - lam) * bx[idx]
    return mixed_x, by, by[idx], lam


def train_epoch(model, loader, optimizer, criterion, scaler):
    model.train()
    total_loss=0.0; all_preds=[]; all_labels=[]
    for bx, by in tqdm(loader, desc="  train", leave=False):
        bx, by = bx.to(DEVICE), by.to(DEVICE)
        optimizer.zero_grad()
        use_mixup = random.random() < 0.6
        with torch.cuda.amp.autocast(enabled=torch.cuda.is_available()):
            if use_mixup:
                mixed_x, ya, yb, lam = mixup_batch(bx, by)
                logits = model(mixed_x)
                loss   = lam * criterion(logits, ya) + (1-lam) * criterion(logits, yb)
            else:
                logits = model(bx)
                loss   = criterion(logits, by)
        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        scaler.step(optimizer); scaler.update()
        total_loss += loss.item()
        all_preds.extend(logits.argmax(1).detach().cpu().numpy())
        all_labels.extend(by.cpu().numpy())
    return total_loss/len(loader), f1_score(all_labels,all_preds,average="macro",zero_division=0)


@torch.no_grad()
def eval_epoch(model, loader, criterion):
    model.eval()
    total_loss=0.0; all_preds=[]; all_labels=[]
    for bx, by in tqdm(loader, desc="  val  ", leave=False):
        bx, by = bx.to(DEVICE), by.to(DEVICE)
        with torch.cuda.amp.autocast(enabled=torch.cuda.is_available()):
            logits = model(bx); loss = criterion(logits, by)
        total_loss += loss.item()
        all_preds.extend(logits.argmax(1).cpu().numpy())
        all_labels.extend(by.cpu().numpy())
    f1 = f1_score(all_labels,all_preds,average="macro",zero_division=0)
    return total_loss/len(loader), f1, all_preds, all_labels


def run_training(model, train_df, val_df, run_name, model_fname, lr=LR,
                 backbone_params=None, head_params=None):
    """
    Generic training runner used by all three models.
    If backbone_params is given, uses dual LR (backbone×0.1, head×1.0).
    """
    train_loader = DataLoader(MelSpecDataset(train_df, augment=True),
                              batch_size=BATCH_SIZE, shuffle=True,
                              num_workers=NUM_WORKERS, pin_memory=True)
    val_loader   = DataLoader(MelSpecDataset(val_df,   augment=False),
                              batch_size=BATCH_SIZE, shuffle=False,
                              num_workers=NUM_WORKERS, pin_memory=True)

    criterion = nn.CrossEntropyLoss(label_smoothing=0.1)

    if backbone_params is not None:
        optimizer = optim.AdamW([
            {"params": backbone_params, "lr": lr * 0.1},
            {"params": head_params,     "lr": lr},
        ], weight_decay=WEIGHT_DECAY)
    else:
        optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=WEIGHT_DECAY)

    # CosineAnnealingWarmRestarts gives multiple restarts → better generalization
    scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(
        optimizer, T_0=20, T_mult=2, eta_min=1e-6)
    scaler    = torch.cuda.amp.GradScaler(enabled=torch.cuda.is_available())

    save_path = os.path.join(MODELS_DIR, model_fname)
    best_f1, patience_count = 0.0, 0

    total, trainable = count_params(model)
    wandb.init(project=WANDB_PROJECT, entity=WANDB_ENTITY, name=run_name, config={
        "model": run_name, "epochs": NUM_EPOCHS, "batch_size": BATCH_SIZE,
        "lr": lr, "total_params": total, "trainable_params": trainable,
        "chunk_duration": CHUNK_DURATION, "full_duration": DURATION,
    })
    wandb.watch(model, log_freq=200)

    print(f"  Params: {total:,} total / {trainable:,} trainable")
    print(f"  Train chunks: {len(train_df)}  |  Val chunks: {len(val_df)}")
    print(f"\n{'Epoch':>6} {'TrLoss':>8} {'TrF1':>7} {'VaLoss':>8} {'VaF1':>7} {'LR':>9}")
    print("-"*50)

    for epoch in range(1, NUM_EPOCHS+1):
        tr_loss, tr_f1       = train_epoch(model, train_loader, optimizer, criterion, scaler)
        va_loss, va_f1, _, _ = eval_epoch(model, val_loader, criterion)
        scheduler.step(epoch)
        lr_cur = optimizer.param_groups[0]["lr"]

        print(f"{epoch:>6} {tr_loss:>8.4f} {tr_f1:>7.4f} {va_loss:>8.4f} {va_f1:>7.4f} {lr_cur:>9.6f}")
        wandb.log({"epoch":epoch,"train/loss":tr_loss,"train/f1":tr_f1,
                   "val/loss":va_loss,"val/f1":va_f1,"lr":lr_cur})

        if va_f1 > best_f1:
            best_f1 = va_f1; patience_count = 0
            torch.save({"epoch":epoch,"model_state":model.state_dict(),
                        "val_f1":va_f1,"num_classes":NUM_CLASSES,
                        "model_name":run_name}, save_path)
            print(f"  ✓ Best saved (val F1={va_f1:.4f})")
        else:
            patience_count += 1
            if patience_count >= PATIENCE:
                print(f"  Early stop at epoch {epoch}"); break

    # Final report
    ckpt = torch.load(save_path, map_location=DEVICE)
    model.load_state_dict(ckpt["model_state"])
    _, _, preds, labels = eval_epoch(model, val_loader, criterion)
    print(f"\nFinal Classification Report (best checkpoint):")
    print(classification_report(labels, preds, target_names=GENRES, digits=4))
    wandb.log({"best_val_f1":best_f1}); wandb.finish()
    print(f"Best Val F1 : {best_f1:.4f}")
    return best_f1


# ── Load manifests ─────────────────────────────────────────────────────────────
wandb.login(key=WANDB_API_KEY)
train_df = pd.read_csv(os.path.join(FEATURES_DIR, "train_manifest.csv"))
val_df   = pd.read_csv(os.path.join(FEATURES_DIR, "val_manifest.csv"))
print(f"Train chunks: {len(train_df)}  |  Val chunks: {len(val_df)}")

# ── Train EfficientNet CNN ──────────────────────────────────────────────────
model = EfficientNetMelCNN(num_classes=NUM_CLASSES).to(DEVICE)
backbone_p = [p for n,p in model.named_parameters() if "classifier" not in n]
head_p     = [p for n,p in model.named_parameters() if "classifier" in n]
run_training(model, train_df, val_df,
             run_name="efficientnet_cnn_v2",
             model_fname="cnn_best.pth",
             backbone_params=backbone_p,
             head_params=head_p)
