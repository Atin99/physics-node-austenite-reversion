# Project Status

This package is the cleaned project handoff.

## Current State

- Core source tree is present and organized for local work.
- Static reference data is present.
- Figures already generated for the project are included.
- Tests remain available in `tests/`.
- The `models/checkpoints/` directory is kept as the destination for future trained weights.

## Package Intent

This folder is meant to be readable, portable, and easy to continue from.
It is set up as a clean source package rather than an experiment dump.

## Suggested Next Work

1. Review `config.py` and `trainer.py` before the next training pass.
2. Recreate the desired training run and place any chosen checkpoints under `models/checkpoints/`.
3. Refresh figures after retraining if the updated model changes the reported trends.
4. Keep future experiment archives outside this clean package unless they are explicitly selected for release.
