Place selected trained model checkpoints in this directory.

Keep only the checkpoints you want to preserve for the clean release package.
